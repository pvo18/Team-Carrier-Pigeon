# Manifest

Source: Dynamics 365 `willisprod` + `crosbyprod` (read-only).
Censoring date 2026-09-15. Extract built 2026-09-15 23:00 UTC.

Verify with `sha256sum -c SHA256SUMS`, or on Windows
`powershell -ExecutionPolicy Bypass -File verify.ps1`, from the archive root.

| file | rows | bytes | sha256 |
|---|---|---|---|
| `DATA_DICTIONARY.md` | — | 10973 | `f5c2ecc59811f3c0a6aaf37afbf0914d838c2c6f7dba35a23462fa1a261c994e` |
| `README.md` | — | 15952 | `e6c9b8e42e573d71f8e8bd4f6d5e93b73e506c04d9d99bdbe01b6bf8f399eb20` |
| `data/clv_baseline_by_segment.csv` | 46 | 3647 | `dd7c198eea2aa5f18b844bdc15f3fc683b72be91596a3cde8afff3ee39a46329` |
| `data/cohort_retention_monthly.csv` | 404 | 12105 | `4c4b1c9fb728a554519818bbec4d0a5b6e44dc3117f6ac90a66acaf701f1a874` |
| `data/cohort_retention_weekly.csv` | 1605 | 49253 | `46ae8865c63bdca16e0f3cb7b49d6f2f95be23a100e6ab5b65e179c2a39092e1` |
| `data/invoice_cycles.csv` | 7566 | 837401 | `aaec08c6984f71336080c313b91070c7e52f8b4d6805fa922c9b898ffcc5d6e7` |
| `data/km_survival.csv` | 128 | 3362 | `870b23d0f54f0a1867ad40e940ef8ddc42b90bb62d3715561ca1a72216db6baa` |
| `data/residents.csv` | 455 | 146337 | `f06dd2f64d63760c3b550295eccdcbfbed397fab98c223013aabe5d1a5826f3c` |
| `data/sensitivity_checks.csv` | 15 | 1749 | `b7b65c902cc0eb48850678bc92d162b85ab30d72755a1d6b018b228b449524a1` |
| `data/weekly_panel.csv` | 6731 | 560728 | `3e8a0b63c1ddd05708f7b4c2fd45a30276b83302199278ac5441dba534742120` |
| `verify.ps1` | — | 571 | `9fc9b0edba35910d72ba72ac4794aa8d984d7197262cd34cbf193bd2ec11a1aa` |
