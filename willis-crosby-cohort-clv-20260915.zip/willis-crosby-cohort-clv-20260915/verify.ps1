# Verify SHA256SUMS on Windows. Run from the unzipped folder.
$fail = 0
Get-Content SHA256SUMS | ForEach-Object {
    if ($_ -match '^\s*$') { return }
    $parts    = $_ -split '\s+', 2
    $expected = $parts[0]
    $file     = $parts[1]
    if (-not (Test-Path -LiteralPath $file)) { "MISSING  $file"; $fail++; return }
    $actual = (Get-FileHash -LiteralPath $file -Algorithm SHA256).Hash
    if ($actual -ieq $expected) { "OK       $file" } else { "MISMATCH $file"; $fail++ }
}
if ($fail -eq 0) { "`nAll files verified." } else { "`n$fail file(s) failed."; exit 1 }
